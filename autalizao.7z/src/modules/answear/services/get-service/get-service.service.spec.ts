import { Test, TestingModule } from '@nestjs/testing';
import { GetAnswearService } from './get-answear.service'; describe('GetServiceService', () => {
  let service: GetAnswearService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [GetAnswearService],
    }).compile();

    service = module.get<GetAnswearService>(GetAnswearService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
