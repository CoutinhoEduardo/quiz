import { Test, TestingModule } from '@nestjs/testing';
import { AnswearService } from './posts-answear.service';

describe('AnswearService', () => {
  let service: AnswearService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [AnswearService],
    }).compile();

    service = module.get<AnswearService>(AnswearService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
