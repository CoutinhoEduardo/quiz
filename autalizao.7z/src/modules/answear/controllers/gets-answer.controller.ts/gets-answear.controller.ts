import { Controller, Get, Param, Query } from "@nestjs/common";
import { AnswerEntity } from "src/typeorm/entities/answear.entity";
import { GetAnswearService } from "../../services/get-service/get-answear.service";
import { FilteredAnswerDto } from "../../dtos/filteredAnswer.dto";

@Controller('answear')
export class AnswearGetsController {

  constructor(private readonly answearService: GetAnswearService) { }

  @Get()
  getAswears(): Promise<Array<AnswerEntity>> {
    return this.answearService.getAnswears();
  }

  @Get(':id')
  getAnswearsById(@Param('id') id: string): Promise<AnswerEntity> {
    return this.answearService.getAnswearById(id);
  }

  @Get('findAnswer/filteredAnswers')
  filteredAnswer(@Query() filteredAnswer: FilteredAnswerDto) {
    return this.answearService.filteredAnswers(filteredAnswer);
  }
}
