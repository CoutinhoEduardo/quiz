import { Test, TestingModule } from '@nestjs/testing';
import { PostsAnswearController } from './posts-answear.controller';

describe('AnswearController', () => {
  let controller: PostsAnswearController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PostsAnswearController],
    }).compile();

    controller = module.get<PostsAnswearController>(PostsAnswearController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
