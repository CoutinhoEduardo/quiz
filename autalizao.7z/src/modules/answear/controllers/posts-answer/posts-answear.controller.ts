import { Body, Controller, Post, Req } from '@nestjs/common';
import { PostsAnswearService } from '../../services/posts-answear/posts-answear.service';
import { CreateAnswearDto } from '../../dtos/create-answear.dto';
import { Request } from 'express';

@Controller('answear')
export class PostsAnswearController {

  constructor(private readonly answearService: PostsAnswearService) { }

  @Post()
  createAnswear(@Body() answear: CreateAnswearDto, @Req() request: Request) {
    return this.answearService.createAnswear(answear, request)
  }
}
