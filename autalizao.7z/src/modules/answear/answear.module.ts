import { Module } from '@nestjs/common';
import { PostsAnswearController } from './controllers/posts-answer/posts-answear.controller';
import { PostsAnswearService } from './services/posts-answear/posts-answear.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AnswerEntity } from 'src/typeorm/entities/answear.entity';
import { GetAnswearService } from './services/get-service/get-answear.service';
import { AuthModule } from '../auth/auth.module';
import { AnswearGetsController } from './controllers/gets-answer.controller.ts/gets-answear.controller';

@Module({
  imports: [
    TypeOrmModule.forFeature([AnswerEntity]),
    AuthModule
  ],
  controllers: [PostsAnswearController, AnswearGetsController],
  providers: [PostsAnswearService, GetAnswearService]
})
export class AnswearModule { }
